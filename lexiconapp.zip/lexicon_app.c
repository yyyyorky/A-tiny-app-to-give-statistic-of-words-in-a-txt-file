#include <stdio.h>
#include "Lexicon.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char** argv) {
    if (argc==1) {
        printf("missing name of file\n");
        return 0;
    }
    Lexicon lex=lexiconCreate(argv[1]);
    if (lex==NULL){return 0;}
    LexiconResult k=lexiconStatistics(lex, argv[1]);
    if (argc==2 && k==SUCCESS)  {
        int len=strlen(popular_word(lex));
        char* tmp=malloc(len+2);
        strcpy(tmp,popular_word(lex));
        int num=count(lex,tmp);
        printf("%s %d\n",tmp,num);
        free(tmp);
        tmp=NULL;
    }
    if (argc>2 && k==SUCCESS) {
        for (int i=2;i<argc;i++) {
            int num=count(lex, argv[i]);
            printf("%s %d\n",argv[i],num);
        }
    }
    lexiconDestroy(lex);
    return 0;
}
