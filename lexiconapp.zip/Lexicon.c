#include <stdio.h>
#include "Lexicon.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

LexiconResult lexiconUpdate(Lexicon lex, const char* word);
void lexiconDestroy(Lexicon);

Lexicon lexiconCreate(const char *file){
    if (file==NULL) {
        printf("missing name of file");
        return NULL;
    }
    else{
        FILE* fp=NULL;
        fp=fopen(file,"r");
        if (fp==NULL) {
            printf("can not open %s\n",file);
            return NULL;
            }
        Lexicon lex =malloc(sizeof(Lexicon_e));
        if (lex==NULL) {return NULL;}
        lex->physical_len=0;
        lex->len=0;
        lex->words=malloc(sizeof(Word)*10);
        if (lex->words==NULL) {free(lex);lex=NULL;return NULL;}
        /*char* tmp=malloc(1024*sizeof(char));
        while (fscanf(fp,"%s",tmp)!=EOF){
                lexiconUpdate(lex,tmp);}*/

        int position=0;
        int tmpsize=100;
        char* tmp=malloc(tmpsize*sizeof(char));
        if (tmp==NULL) {free(lex->words);lex->words=NULL;free(lex);lex=NULL;return NULL;}
        char c;
        while (1){
            c=fgetc(fp);
            if (!isspace(c)) {
                tmp[position]=c;
                position++;
            }
            if (isspace(c)) {
                tmp[position]='\0';
                lexiconUpdate(lex,tmp);
                for (int i=0;i<=position;i++) {tmp[i]=' ';}
                position=0;
            }
            if (c==EOF) {
                tmp[position]='\0';
                break;
            }
            if (position>=tmpsize-2){
                tmpsize+=100;
                tmp=realloc(tmp,tmpsize);
                if (tmp==NULL) {lexiconDestroy(lex);return NULL;}
                /*char* tmp2=malloc(tmpsize);
                if (tmp2==NULL) {lexiconDestroy(lex);free(tmp);tmp=NULL;return NULL;}
                for (int j=0;j<(position);j++){tmp2[j]=tmp[j];free(tmp);tmp=tmp2;tmp2=NULL;}*/
            }
        }

        free(tmp);
        tmp=NULL;
        fclose(fp);
        return lex;

        }


    }


void lexiconDestroy(Lexicon lex) {
    if (lex==NULL) {return ;}
    for (int i=0;i<lex->len;i++) {
        free(lex->words[i]->text);
        lex->words[i]->text=NULL;
        free(lex->words[i]);
        lex->words[i]=NULL;
    }
    free(lex->words);
    lex->words=NULL;
    free(lex);
    lex=NULL;
    return ;

}

LexiconResult lexiconUpdate(Lexicon lex, const char* word) {
    if (word[0]=='\0'){return SUCCESS;}
    if (lex->len==0) {
            Word gg=malloc(sizeof(Word_e));
            if (gg==NULL) {return MEMORY_PROBLEM;}
            gg->text=malloc(strlen(word)+2);
            if (gg->text==NULL) {free(gg);gg=NULL;return MEMORY_PROBLEM;}
            strcpy(gg->text,word);
            gg->count=1;
            lex->words[0]=gg;
            gg=NULL;
            lex->len++;
            lex->physical_len++;
            return SUCCESS;
        }
    for (int i=0;i<lex->len;i++){

        if (strcmp(lex->words[i]->text,word)==0){
            lex->words[i]->count++;
            lex->physical_len++;
            return SUCCESS;
        }

        if ((i==lex->len-1) && (strcmp(word,lex->words[i]->text)!=0)) {

            if (lex->len%10==0){
                /*Word* words2=malloc((lex->len+10)*sizeof(Word));
                if (!words2) {lexiconDestroy(lex);return MEMORY_PROBLEM;}
                for (int j=0;j<=lex->len-1;j++) {words2[j]=lex->words[j];free(lex->words);lex->words=words2;words2=NULL;}*/
                lex->words=realloc(lex->words,sizeof(Word)*(lex->len+10));
                if (lex->words==NULL) {lexiconDestroy(lex);return MEMORY_PROBLEM;}

            }
            Word gg=malloc(sizeof(Word_e));
            if (gg==NULL) {return MEMORY_PROBLEM;}
            gg->text=malloc(strlen(word)+2);
            if (gg->text==NULL) {free(gg);gg=NULL;return MEMORY_PROBLEM;}
            strcpy(gg->text,word);
            gg->count=1;
            lex->words[i+1]=gg;
            gg=NULL;
            lex->len++;
            lex->physical_len++;
            return SUCCESS;
            }
    }
    return PROBLEM;
}

const char *popular_word(const Lexicon lex) {
    if (lex->len==0) {
        return "";
    }
    else {
        int mpw;
        int max=0;
        for(int i=0;i<lex->len;i++){
            if (lex->words[i]->count>max) {
                max=lex->words[i]->count;
                mpw=i;
            }
            if (lex->words[i]->count==max && strcmp(lex->words[i]->text,lex->words[mpw]->text)<0) {
                mpw=i;
            }
        }
        return lex->words[mpw]->text;
    }
}

unsigned int count(const Lexicon lex, const char* word){
    unsigned int num=0;
    for(int i=0;i<lex->len;i++){
        if (strcmp(word,lex->words[i]->text)==0) {
            num=lex->words[i]->count;
        }

    }
    return num;
}

LexiconResult lexiconStatistics(const Lexicon lex, const char *file){
    FILE* fpp=fopen(file,"r");
    if (((fpp)==NULL)||lex==NULL) {
            printf("can not calculate result");
            return PARAMETER_PROBLEM;
            }
    fclose(fpp);
    const char* stat="stat_";
    char* newfile=malloc(sizeof(char)*(strlen(stat)+strlen(file))+2);
    int slash=-1;
    for (int position=strlen(file);position>=0;position--) {
        if (file[position]=='/') {
            slash=position;

            break;
        }
    }
    if (slash==-1){
        sprintf(newfile,"%s%s",stat,file);
    }
    else{
        char* str1=malloc(strlen(file)+1);
        if (str1==NULL) {return MEMORY_PROBLEM;}
        char* str2=malloc(strlen(file)+1);
        if (str2==NULL) {free(str1);str1=NULL;return MEMORY_PROBLEM;}
        for (int i=0;i<=slash;i++) {
            str1[i]=file[i];

        }
        str1[slash+1]='\0';
        for (int i=0;i<(strlen(file)-slash+1);i++) {
            str2[i]=file[slash+1+i];

        }
        sprintf(newfile,"%s%s%s",str1,stat,str2);
        free(str1);
        str1=NULL;
        free(str2);
        str2=NULL;
    }

    for (int i=0;i<lex->len;i++){
        for (int j=i+1;j<lex->len;j++){
            if (strcmp(lex->words[i]->text,lex->words[j]->text)>0) {
                Word tmp=lex->words[i];
                lex->words[i]=lex->words[j];
                lex->words[j]=tmp;
            }
        }
    }

    FILE *fp=fopen(newfile,"w+");
    if (fp==NULL) {printf("can not calculate results");return PARAMETER_PROBLEM;}

        for (int i=0;i<lex->len;i++){
            char* tmp=lex->words[i]->text;
            int tmpcount=lex->words[i]->count;
            fprintf(fp,"%d: %s\n", tmpcount,tmp);
         }
        free(newfile);
        newfile=NULL;
        fclose(fp);
        return SUCCESS;



}
