#ifndef LEXICON_H
#define LEXICON_H

typedef struct word
{
    unsigned int count;
    char *text;
} Word_e, *Word;

typedef struct lexicon
{
    unsigned int physical_len;   /* number of physical places for elements that appear in the current words array */
    unsigned int len;            /* number of different words exist in the lexicon */
    Word *words;                 /* array of the words */
} Lexicon_e, *Lexicon;

typedef enum lex
{SUCCESS, MEMORY_PROBLEM, PARAMETER_PROBLEM, PROBLEM}
LexiconResult;

Lexicon lexiconCreate(const char *file); /* create a lexicon. The lexicon is a pointer to struct lexicon.
                                            The field words is an array of pointers. Each element in the array is a pointer to
                                            struct word. struct word has 2 fields : text - the word. count - how many times
                                            it appears in the file. No need to have the words array sorted. (of course it's possible
                                            to do have it sorted, but no need in this HW.
                                            NULL is returned if can not create the lexicon due to any reason, as memory problem,
                                            illegal file contents etc.
                                            NULL file parameter is treated as a BUG. */

void lexiconDestroy(Lexicon);  /* destroy the lexicon. Free all relevant memory.
                                  for the case of NULL Lexicon parameter, the functions does NOTHING. */

LexiconResult lexiconUpdate(Lexicon lex, const char* word);  /* update the lexicon for word. if wrd does not exist in lex, then
                                                                add it. Otherwise increment its count by 1. */

const char *popular_word(const Lexicon lex); /* returns a new created string - the most popular word in lex. */
                                             /* if lex is empty, returns an empty string "".
                                                NULL lex parameter is treated as a BUG. */

unsigned int count(const Lexicon lex, const char* word); /* returns how many times word appears in lex.
                                                            any NULL parameter is treated as a BUG. for non NULL lex, assume it's legal */

LexiconResult lexiconStatistics(const Lexicon lex, const char *file); /* creates a statistics file for the lexicon.
                                                                         The name of file is given as a parameter. if the file
                                                                         already exists then it will be overwritten.
                                                                         any NULL parameter is treated as a BUG.
                                                                         if can not create the file from any reason, PROBLEM is returned. */

#endif
